package com.example.scrapbooking2;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set image resources
        ImageView image1 = findViewById(R.id.image1);
        image1.setImageResource(R.drawable.china_wall);

        ImageView image2 = findViewById(R.id.image2);
        image2.setImageResource(R.drawable.statue_of_liberty);

        ImageView image3 = findViewById(R.id.image3);
        image3.setImageResource(R.drawable.eiffel_tower);

        // Set text labels
        TextView text1 = findViewById(R.id.text1);
        text1.setText("The Great Wall of China");

        TextView text2 = findViewById(R.id.text2);
        text2.setText("Statue of Liberty");

        TextView text3 = findViewById(R.id.text3);
        text3.setText("Eiffel Tower");
    }
}
